MASTERS SHOW — ANDROID APK BUILD PACKAGE (Version 2)

This package is prepared for a cloud build from an Android phone. It contains:
- Native Android WebView wrapper project
- Masters Show V2 web app in app/src/main/assets/index.html
- GitHub Actions workflow that builds a debug APK and saves it as an artifact

IMPORTANT
- This is build source, NOT the APK itself.
- A cloud build must run before there is an APK to install.
- The generated debug APK is for personal testing/installing. It is not a Play Store release.
- The app needs internet for Internet Archive links/streams. Its own interface is bundled.
- The current TV entries are archive discovery links. Offline movie/episode downloads are not implemented inside the app; use a source's download function only where its licence permits it.
- Public-domain status can differ by country and by version.

BUILD FROM YOUR ANDROID PHONE
1. Download and extract this ZIP using your phone's Files app.
2. Sign in to GitHub or create a free account at https://github.com/.
3. In GitHub, create a new repository named masters-show-android. Public is simplest for this workflow; do not upload passwords or private data.
4. In the repository, use Add file > Upload files. Upload the contents of the extracted MastersShowAndroid folder (including the .github folder). GitHub mobile may require opening github.com in Chrome and enabling Desktop site to upload folders.
5. Commit the files to the main branch.
6. Open the repository's Actions tab. Select "Build Masters Show APK". Tap Run workflow if it has not started automatically.
7. Wait for the workflow to finish successfully. Open the completed run and find Artifacts > Masters-Show-debug-APK.
8. Download the artifact ZIP, extract it, then tap app-debug.apk to install. Android may ask you to allow Chrome/Files to install unknown apps.

If GitHub's mobile upload flow hides the .github folder, use the website's desktop-site mode in Chrome or upload files individually while preserving their folder paths.
